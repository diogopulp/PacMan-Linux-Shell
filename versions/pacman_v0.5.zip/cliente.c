#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <ncurses.h>
#include <pthread.h>

#define WIDTH 57
#define HEIGHT 24

struct timeval tempo;

typedef struct {
   char nome[30], passwd[30];
   int  pid, posX, posY, boneco;// ADICIONAR pid (int) / boneco 0 se pacman outro se glutao

} PEDIDO;

typedef struct{

    char mat[22][19];

} RESPOSTA_MAPA;

//VARIAVEIS GLOBAIS

int highlightx = 16, highlighty = 9;
int tamx = 22, tamy =19;
char mat[22][19];

char cp[20];   // DECLARA STRING "cp"

int startx = (80 - WIDTH) /2;
int starty = (24 - HEIGHT) /2;

WINDOW *game_win;

void print_game(WINDOW *game_win, int highlightx, int highlighty){
		int i, j;
		int x=1, y=1;

		box(game_win, 0, 0);

		for(i = 0; i < tamx; i++){
			for(j = 0;j< tamy; j++){
				if(highlightx == i && highlighty == j){ /* High light the present choice */

					//wattron(game_win, A_REVERSE);
					wattron(game_win,COLOR_PAIR(2));
					mvwprintw(game_win, y, x, "%c", mat[i][j]);
					wattroff(game_win,COLOR_PAIR(2));
					//wattroff(game_win, A_REVERSE);

				}else{

					if(mat[i][j]=='*'){

						start_color();
						init_pair(1,COLOR_BLUE,COLOR_BLACK);
						wattron(game_win,COLOR_PAIR(1));
						mvwprintw(game_win, y, x, "%c", mat[i][j]);
						wattroff(game_win,COLOR_PAIR(1));
					}else
					if(mat[i][j]=='o'){

						start_color();
						init_pair(2,COLOR_YELLOW,COLOR_BLACK);
						wattron(game_win,COLOR_PAIR(2));
						mvwprintw(game_win, y, x, "%c", mat[i][j]);
						wattroff(game_win,COLOR_PAIR(2));
					}else
					if(mat[i][j]=='n'){

						start_color();
						init_pair(3,COLOR_MAGENTA,COLOR_BLACK);
						wattron(game_win,COLOR_PAIR(3));
						mvwprintw(game_win, y, x, "%c", mat[i][j]);
						wattroff(game_win,COLOR_PAIR(3));
					}else
					mvwprintw(game_win, y, x, "%c", mat[i][j]);



				}
				x+=3;
			}
			x=1;
			y++;
		}

		wrefresh(game_win);
}

int main(void) {
  system("clear");
   int fd, res, fd_resp;
   int comando;
   int i, j;
   PEDIDO p;
   RESPOSTA_MAPA mapa;
   fd_set fontes;

   if (access("dados.bin", F_OK)!=0) { // CONFIRMAR SE EXISTE SERVIDOR
      printf("[ERRO] Nao existe servidor!\n");
      exit(1);
   }

   printf("\nNome: ");
   scanf("%s", p.nome);
   printf("\nPassword: ");
   scanf("%s", p.passwd);

   p.pid = getpid(); // FIFO CLIENTE "p.nome" -> "p.pid"
   sprintf(cp, "%d", p.pid);

   mkfifo(cp, 0600); // mkfifo, open, unlink... CRIA O PIPE

   fd = open("dados.bin", O_WRONLY);
   res = write(fd, &p, sizeof(PEDIDO));

   close(res);

   fd_resp = open(cp, O_RDONLY);
   res = read(fd_resp, &mapa, sizeof(RESPOSTA_MAPA)); // RECEBE MAPA DO SERVIDOR


   // COPIA MAPA PARA MATRIZ LOCAL
   for(i=0;i<22;i++){
     for(j=0;j<19;j++){
       mat[i][j]=mapa.mat[i][j];
     }
   }

   close(res);

   initscr();
   clear();
   noecho();
   cbreak();

   // IMPRIME JOGO
   game_win = newwin(HEIGHT, WIDTH, starty, startx); // CRIA JANELA DE JOGO
   print_game(game_win, starty, startx);

   keypad(game_win, TRUE);
   refresh();

   while(1){

    FD_ZERO(&fontes);
    FD_SET(0, &fontes);    // TECLADO...
    FD_SET(fd, &fontes);   // FIFO...
    tempo.tv_sec  = 3;     // TEMPO DE ESPERA...
    tempo.tv_usec = 0;

    res = select(fd+1, &fontes, NULL, NULL, &tempo);

    // 1. LE DO TECLADO
    if (res>0 && FD_ISSET(0,&fontes)) {
        comando = wgetch(game_win); // FALTA IMPLEMENTAR CONFIRMACAO DO LADO DO SERVIDOR

          switch(comando){
            case KEY_UP:
              p.posX--;
              fd = open("dados.bin", O_WRONLY);
              res = write(fd, &p, sizeof(PEDIDO));
              close(res);
              break;

            case KEY_DOWN:
              p.posX++;
              fd = open("dados.bin", O_WRONLY);
              res = write(fd, &p, sizeof(PEDIDO));
              close(res);
              break;

            case KEY_LEFT:
              p.posY--;
              fd = open("dados.bin", O_WRONLY);
              res = write(fd, &p, sizeof(PEDIDO));
              close(res);
              break;

            case KEY_RIGHT:
              p.posY++;
              fd = open("dados.bin", O_WRONLY);
              res = write(fd, &p, sizeof(PEDIDO));
              close(res);
              break;

            default:
              refresh();
              break;
          }

          print_game(game_win, highlightx, highlighty);

        }


      }

   clrtoeol();
   refresh();
   endwin();

   return 0;
}
