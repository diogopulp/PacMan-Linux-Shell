#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>   // INCLUIR BIBLIOTECA SINAIS

typedef struct {
   char nome[30];
   int  pid, num1, num2, soma;   // ADICIONAR "pid" (int)
} PEDIDO;

char cp[20];   // DECLARA STRING "cp"

void msg_urgente(int s) {   // FUNCAO "msg_urgente"
   int fd2, res2;
   PEDIDO r;

   printf("\nMSG Urgente! (servidor)\n");

   // RECEBER RESPOSTA - open,read,close
   fd2 = open(cp, O_RDONLY);
   res2 = read(fd2, &r, sizeof(PEDIDO));
   printf("  %d + %d = %d (%s)\n", r.num1, r.num2, r.soma, r.nome);
   close(fd2);
}

int main(void) {
   int fd, res, fd_resp;
   PEDIDO p;

   signal(SIGUSR1, msg_urgente);  // "SIGUSR1"->"msg_urgente"
   if (access("dados.bin", F_OK)!=0) {
      printf("[ERRO] Nao existe servidor!\n");
      exit(1);
   }
   printf("Nome? ");   scanf("%s", p.nome);
   p.pid = getpid(); // FIFO CLIENTE "p.nome" -> "p.pid"
   sprintf(cp, "%d", p.pid);
   mkfifo(cp, 0600); // mkfifo, open, unlink...
   fd = open("dados.bin", O_WRONLY);
   do {
      printf("Num1? ");   scanf("%d", &(p.num1));
      printf("Num2? ");   scanf("%d", &(p.num2));
      res = write(fd, &p, sizeof(PEDIDO));
      printf("Escrevi %d bytes...\n", res);

      fd_resp = open(cp, O_RDONLY);
      res = read(fd_resp, &p, sizeof(PEDIDO));
      printf("Li %d bytes...\n", res);
      printf("  %d + %d = %d\n", p.num1, p.num2, p.soma);
      close(fd_resp);
   } while(!(p.num1==0 && p.num2==0));
   close(fd);
   unlink(cp);

   exit(0);
}
