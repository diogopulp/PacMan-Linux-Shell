#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>   // INCLUIR BIBLIOTECA SINAIS
#include <sys/time.h>
#include <sys/select.h>

typedef struct {
   char nome[30];
   int  pid, num1, num2, soma; // ADICIONAR pid (int)
} PEDIDO;

int main(void) {
   int fd, res, fd_resp, i;
   PEDIDO p;
   char cp[20];   // STRING cp
   int cliente[] = {-1,-1,-1,-1,-1}; // ARRAY cliente[] (int)


   char cmd[20];
   fd_set fontes;
   struct timeval tempo;


   mkfifo("dados.bin", 0600);
   fd = open("dados.bin", O_RDWR);
   do {

      FD_ZERO(&fontes);
      FD_SET(0, &fontes);    // TECLADO...
      FD_SET(fd, &fontes);   // FIFO...
      tempo.tv_sec  = 3;     // TEMPO DE ESPERA...
      tempo.tv_usec = 0;
      res = select(fd+1, &fontes, NULL, NULL, &tempo);

      if (res==0) {   // TIMEOUT...
         printf(".");
         fflush(stdout);
      }

      if (res>0 && FD_ISSET(0,&fontes)) {   // TECLADO: scanf(); -> read( 0, ...);
        scanf("%s", cmd);
        if (strcmp(cmd, "sair")==0)
           break;
        if (strcmp(cmd, "clientes")==0)
           printf("CLIENTES: %d %d %d %d %d\n", cliente[0], cliente[1], cliente[2], cliente[3], cliente[4]);
      }

      if (res>0 && FD_ISSET(fd,&fontes)) {   // FIFO:                read(fd, ...);
        res = read(fd, &p, sizeof(PEDIDO));
        printf("Li %d bytes...\n", res);
        if (res==sizeof(PEDIDO)) {
           // ADICIONAR "pid" A LISTA CLI. (1º PEDIDO)
           int existe, pos_livre;
           existe = 0;   pos_livre = -1;
           for (i=0; i<5; i++) {
              if (cliente[i]==p.pid)
                 existe = 1;
              if (pos_livre==-1 && cliente[i]==-1)
                 pos_livre = i;
           }
           if (existe==0  && pos_livre!=-1)
              cliente[pos_livre] = p.pid;

           // REMOVER "pid" DA LISTA CLI. (PEDIDO=0+0)
           if (p.num1==0 && p.num2==0)
              for (i=0; i<5; i++)
                 if (cliente[i]==p.pid) {
                    cliente[i] = -1;
                    break;
                 }

           // MOSTRAR LISTA DE CLIENTES...

           p.soma = p.num1 + p.num2;
           printf("  %d + %d = %d (%s)\n", p.num1, p.num2, p.soma, p.nome);

           sprintf(cp, "%d", p.pid);  // FIFO CLIENTE "p.nome" -> "p.pid"
           fd_resp = open(cp, O_WRONLY);
           res = write(fd_resp, &p, sizeof(PEDIDO));
           printf("Escrevi %d bytes...\n", res);
           close(fd_resp);

           // NOTIFICAR "OUTROS" CLI. (!=-1 E !=p.pid)
           for (i=0;i<5;i++)
              if (cliente[i]!=-1 && cliente[i]!=p.pid) {
                 kill(cliente[i], SIGUSR1);  // ENVIAR SIG..

                 // ENVIAR RESPOSTA - open, write, close
                 sprintf(cp, "%d", cliente[i]);
                 fd_resp = open(cp, O_WRONLY);
                 res = write(fd_resp, &p, sizeof(PEDIDO));
		
                 printf("Escrevi %d bytes...\n", res);
                 close(fd_resp);
              }
         }
      }
	
	
   } while(1);
   close(fd);
   unlink("dados.bin");

   exit(0);
}
