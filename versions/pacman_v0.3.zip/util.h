int menu();
void jogo();
void print_game(WINDOW *menu_win, int highlightx, int highlighty);
void print_menu(WINDOW *menu_win, int highlight);
void *musica(void *dados);
int login(char user[10], char passwd[10]);
