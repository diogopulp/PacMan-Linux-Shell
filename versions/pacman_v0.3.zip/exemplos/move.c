#include <stdio.h>
#include <ncurses.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define WIDTH 57
#define HEIGHT 24

void print_game(WINDOW *menu_win, int highlightx, int highlighty);


void *musica(void *dados){

int i;
long max;

max = (long) dados;
system("afplay Disorder.m4a");
pthread_exit(NULL);

}


int startx = 0;
int starty = 0;

int tamx = 22, tamy =19;
char mat[22][19];


WINDOW *game_win;


// MAIN
int main(void){

initscr();
clear();
noecho();
cbreak();
system("clear");

printf("Welcome to Pacman!");
system("say Welcome to pacman!");


clrtoeol();
refresh();
endwin();


long limite;

pthread_t tarefa;
pthread_create(&tarefa, NULL, musica, (void*) limite); // MUSICA THREAD



int x,y,num = 10;
int c;
int highlightx = 16, highlighty = 9;

int i,j;

for(i=0;i<tamx;i++){
	for(j=0;j<tamy;j++){
		mat[i][j] = ' ';
	}

}

for(i=0;i<tamx;i++){
	for(j=0;j<tamy;j++){
		if(mat[i][j] == ' ')mat[i][j] = '.';
	}

}


for(x=0;x<tamx;x++){ // PREECHE MATRIZ
	for(y=0;y<tamy;y++){
		
		// LADOS		
			
		for(i=0;i<tamx;i++){for(j=0;j<1;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=0;i<1;i++){for(j=1;j<tamy;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=1;i<tamx;i++){for(j=tamy-1;j<tamy;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=tamx-1;i<tamx;i++){for(j=1;j<tamy-1;j++)if(x==i&&y==j)mat[x][y]='*';}

		// CAMPO

		for(i=2;i<4;i++){for(j=2;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=2;i<4;i++){for(j=5;j<8;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=1;i<4;i++){for(j=9;j<10;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=2;i<4;i++){for(j=11;j<14;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=2;i<4;i++){for(j=15;j<17;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=5;i<6;i++){for(j=2;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=7;i<8;i++){for(j=1;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=8;i<9;i++){for(j=3;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=5;i<6;i++){for(j=2;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=5;i<10;i++){for(j=5;j<6;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=7;i<8;i++){for(j=6;j<8;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=5;i<6;i++){for(j=7;j<12;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=6;i<8;i++){for(j=9;j<10;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=5;i<10;i++){for(j=13;j<14;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=7;i<8;i++){for(j=11;j<13;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=5;i<6;i++){for(j=15;j<17;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=7;i<8;i++){for(j=15;j<18;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=8;i<9;i++){for(j=15;j<16;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=9;i<10;i++){for(j=1;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=9;i<10;i++){for(j=15;j<18;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=9;i<10;i++){for(j=7;j<9;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=9;i<10;i++){for(j=10;j<12;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=10;i<11;i++){for(j=7;j<8;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=10;i<11;i++){for(j=11;j<12;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=11;i<12;i++){for(j=1;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=11;i<14;i++){for(j=5;j<6;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=11;i<12;i++){for(j=7;j<12;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=11;i<14;i++){for(j=13;j<14;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=11;i<12;i++){for(j=15;j<18;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=12;i<14;i++){for(j=3;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=12;i<13;i++){for(j=15;j<16;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=13;i<14;i++){for(j=1;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=13;i<14;i++){for(j=7;j<12;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=13;i<14;i++){for(j=15;j<18;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=14;i<16;i++){for(j=9;j<10;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=15;i<16;i++){for(j=2;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=15;i<16;i++){for(j=5;j<8;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=15;i<16;i++){for(j=11;j<14;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=15;i<16;i++){for(j=15;j<17;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=16;i<18;i++){for(j=3;j<4;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=16;i<18;i++){for(j=15;j<16;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=17;i<18;i++){for(j=1;j<2;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=17;i<18;i++){for(j=17;j<18;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=17;i<19;i++){for(j=5;j<6;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=17;i<18;i++){for(j=7;j<12;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=17;i<19;i++){for(j=13;j<14;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=18;i<20;i++){for(j=9;j<10;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=19;i<20;i++){for(j=2;j<8;j++)if(x==i&&y==j)mat[x][y]='*';}
		for(i=19;i<20;i++){for(j=11;j<17;j++)if(x==i&&y==j)mat[x][y]='*';}

		// ESPECIAIS

		for(i=8;i<9;i++){for(j=0;j<3;j++)if(x==i&&y==j)mat[x][y]=' ';}
		for(i=8;i<9;i++){for(j=16;j<tamy;j++)if(x==i&&y==j)mat[x][y]=' ';}
		for(i=12;i<13;i++){for(j=0;j<3;j++)if(x==i&&y==j)mat[x][y]=' ';}
		for(i=12;i<13;i++){for(j=16;j<tamy;j++)if(x==i&&y==j)mat[x][y]=' ';}
	
		for(i=10;i<11;i++){for(j=0;j<1;j++)if(x==i&&y==j)mat[x][y]='.';}
		for(i=10;i<11;i++){for(j=tamy-1;j<tamy;j++)if(x==i&&y==j)mat[x][y]='.';}

	}
}



// IMPRIME PARA O ECRA

initscr();
clear();
noecho();
cbreak();

startx = (80 - WIDTH) /2;
starty = (24 - HEIGHT) /2;

game_win = newwin(HEIGHT, WIDTH, starty, startx); // CRIA JANELA DE JOGO
keypad(game_win, TRUE);
refresh();

print_game(game_win, highlightx, highlighty);



while(1){
c=wgetch(game_win);
	switch(c){
		case KEY_UP:
			if(mat[highlightx-1][highlighty]=='*')break; // DETETA PAREDE
			if(highlightx == 0)
				highlightx=tamx-1;
			else
				--highlightx;
			break;

		case KEY_DOWN:
			if(mat[highlightx+1][highlighty]=='*')break; // DETETA PAREDE
			if(highlightx == tamx-1)
				highlightx = 0;
			else
				++highlightx;
			break;

		case KEY_LEFT:
			
			if(highlighty == 0)
				highlighty = tamy;
			if(mat[highlightx][highlighty-1]=='*')break; // DETETA PAREDE
			else
				--highlighty;
			break;
		case KEY_RIGHT:
			
			if(highlighty == tamy-1)
				highlighty = -1;
			if(mat[highlightx][highlighty+1]=='*')break; // DETETA PAREDE
			else
				++highlighty;
			break;
		default:

			refresh();
			break;
	}
	print_game(game_win, highlightx, highlighty);

}


clrtoeol();
refresh();
endwin();

pthread_exit(NULL);
return 0;
}

void print_game(WINDOW *menu_win, int highlightx, int highlighty)
{
	int i, j;
	int x=1, y=1;

	box(game_win, 0, 0);

	for(i = 0; i < tamx; i++){
		for(j = 0;j<tamy; j++){
			if(highlightx == i && highlighty == j){ /* High light the present choice */
				wattron(game_win, A_REVERSE);
				mvwprintw(game_win, y, x, "%c", mat[i][j]);
				wattroff(game_win, A_REVERSE);

			}else

				mvwprintw(game_win, y, x, "%c", mat[i][j]);


			x+=3;
		}
		x=1;
		y++;
	}

	wrefresh(menu_win);
}
